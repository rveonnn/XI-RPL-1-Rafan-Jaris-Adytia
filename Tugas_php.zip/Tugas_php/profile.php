<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <title>Profile Page</title>
    <style>
body {
    height: 100vh;
    background: linear-gradient(to bottom right, #1E2A5E 0%, #55679C 75%, #7C93C3 100%);
    margin: 0;
    padding: 0;

}

h1 {
    color: #fff;
    font-family: 'poppins';
    font-size: 80px;
    font-weight:bold 700;
    margin-bottom: 20px;
    text-align: center;
}

.box {
    padding-top: 5%;
    padding-left: 30%;

}

.container {
    background-color: #fff;
    border-radius: 32px 64px;
    display: flex;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    padding-left: 80px;
    width: 500px;
    height: 200px;
    align-items: center;
    gap: 70px;
    font-family: 'poppins';
}
.container:hover {
    background-color: #229799;
    color: #fff;
    transition: background-color 0.3s ease;
}
img {
    display: flex;
    width: 150px;
    height: 150px;
    border-radius: 50%;
    overflow: hidden;
    margin-left: 2.5px;
}

a {
    font-family: 'Poppins';
    background-color: #fff;
    height: 60px;
    width: 125px;
    border: 1px;
    border-radius: 32px;
    color: #229799;
    display: grid;
    text-align: center;
    align-items: center;
    place-items: center;
    text-decoration: none;
    margin-top: 60px;
    margin-left: 46%;
    transition: transform 0.3s ease;
}   

a:hover {
    color: #fff;
    background-color: #229799;
    transform: scale(1.05);
}

</style>
<?php
$nama = "Rafan Jaris Adytia";
$umur = "16 ";
$sekolah = "SMKN 2 Bandung";
$waifu = "Nico Robin, Raiden Ei";
$foto = "ppp.jpg";
?>
<h1> Profile</h1>
<div class = "box">
<div class = "container">
    <img src="<?php echo $foto; ?>" alt="Foto">
    <div class= "Profile">
<?php
    echo "Nama : ". $nama. "<br>";
    echo "Umur: ". $umur. "<br>";
    echo "Sekolah : ". $sekolah. "<br>";
    echo "Waifu : ". $waifu. "<br>";
?>
</div>
    </div>
</div>
<a href = "indexphp.html">Back</a>
