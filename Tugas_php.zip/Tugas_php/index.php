<?php
$nama = "Rafan";
$kelas = "XI RPL 1";
$umur = 16;

echo "Nama : ". $nama. "<br>";
echo "Kelas : ". $kelas. "<br>";
echo "Umur : ". $umur. "<br>";
?>
